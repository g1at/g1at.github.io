Place the original challenge `verifier` ELF here. It is not redistributed in this website.
