from pathlib import Path
import json,struct,hashlib,sys
seq=json.loads(Path(sys.argv[1]).read_text());runs=[]
for b in seq:
 if runs and runs[-1][1]==b:runs[-1][0]+=1
 else:runs.append([1,b])
def leb(n):
 out=bytearray()
 while n>=128:out.append((n&127)|128);n>>=7
 out.append(n);return out
data=bytearray(struct.pack('<4sHIQII',b'KSRP',1,1,len(seq),0,len(runs)))
for n,b in runs:data+=leb(n)+bytes([b])
path=Path(sys.argv[2]);path.write_bytes(data)
print('file',path,'frames',len(seq),'tick',len(seq)-1,'seconds',(len(seq)-1)/120,'records',len(runs),'bytes',len(data),'sha256',hashlib.sha256(data).hexdigest())
