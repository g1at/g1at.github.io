"""Emulate selected ELF functions; no guest syscall or host I/O is provided."""
from pathlib import Path
import struct,json
from elftools.elf.elffile import ELFFile
from unicorn import Uc,UC_ARCH_X86,UC_MODE_64,UC_HOOK_CODE,UC_HOOK_INSN
from unicorn.x86_const import *

class Native:
 def __init__(self):
  self.u=Uc(UC_ARCH_X86,UC_MODE_64);u=self.u
  u.mem_map(0,0x80000);u.mem_map(0x1000000,0x2000000);u.mem_map(0x4000000,0x100000)
  self.heap=0x1000000;self.hooks={};self.allocs={};self.stop=0x4000100
  with open(Path(__file__).resolve().parent / 'challenge' / 'verifier','rb') as f:
   e=ELFFile(f)
   for s in e.iter_segments():
    if s['p_type']=='PT_LOAD':u.mem_write(s['p_vaddr'],s.data())
   stub=0x70000
   for s in e.iter_sections():
    if s['sh_type']!='SHT_RELA':continue
    sy=e.get_section(s['sh_link'])
    for r in s.iter_relocations():
     name=sy.get_symbol(r['r_info_sym']).name if r['r_info_sym'] else ''
     value=r['r_addend']
     if name:self.hooks[stub]=name;value=stub;u.mem_write(stub,b'\xc3');stub+=16
     u.mem_write(r['r_offset'],struct.pack('<Q',value))
  self.hooks.update({0x18c70:'rust_alloc',0x18c80:'rust_free',0x18c90:'rust_realloc',0x18ca0:'rust_zeroed',0x18cb0:'shim'})
  for addr in self.hooks:u.hook_add(UC_HOOK_CODE,self.hook,begin=addr,end=addr)
  u.hook_add(UC_HOOK_INSN,self.syscall,None,1,0,UC_X86_INS_SYSCALL)
 def syscall(self,*a):raise RuntimeError('Guest syscall denied')
 def alloc(self,n,align=16):
  p=(self.heap+align-1)&-align;self.heap=p+max(n,1)
  if self.heap>=0x3000000:raise RuntimeError('Emulated heap budget exceeded')
  self.allocs[p]=n;return p
 def hook(self,u,addr,size,data):
  name=self.hooks[addr];a=[u.reg_read(x) for x in [UC_X86_REG_RDI,UC_X86_REG_RSI,UC_X86_REG_RDX,UC_X86_REG_RCX]];v=0
  if name in ('rust_alloc','rust_zeroed'):v=self.alloc(a[0],a[1])
  elif name=='rust_realloc':
   v=self.alloc(a[3],a[2]);u.mem_write(v,bytes(u.mem_read(a[0],min(a[1],a[3]))))
  elif name in ('rust_free','shim','free'):pass
  elif name in ('memcpy','memmove'):u.mem_write(a[0],bytes(u.mem_read(a[1],a[2])));v=a[0]
  elif name=='memset':u.mem_write(a[0],bytes([a[1]&255])*a[2]);v=a[0]
  elif name=='bcmp':v=int(u.mem_read(a[0],a[2])!=u.mem_read(a[1],a[2]))
  else:raise RuntimeError(f'Unsupported guest import: {name}, args {a}')
  u.reg_write(UC_X86_REG_RAX,v);sp=u.reg_read(UC_X86_REG_RSP)
  u.reg_write(UC_X86_REG_RIP,struct.unpack('<Q',u.mem_read(sp,8))[0]);u.reg_write(UC_X86_REG_RSP,sp+8)
 def call(self,addr,*args):
  for r,v in zip([UC_X86_REG_RDI,UC_X86_REG_RSI,UC_X86_REG_RDX,UC_X86_REG_RCX,UC_X86_REG_R8,UC_X86_REG_R9],args):self.u.reg_write(r,v)
  sp=0x40ff008;self.u.mem_write(sp,struct.pack('<Q',self.stop));self.u.reg_write(UC_X86_REG_RSP,sp)
  self.u.emu_start(addr,self.stop,timeout=0,count=2000000)
  if self.u.reg_read(UC_X86_REG_RIP)!=self.stop:raise RuntimeError('Emulation budget exceeded')
  return self.u.reg_read(UC_X86_REG_RAX)

if __name__=='__main__':
 n=Native();world=n.alloc(512);n.call(0x1a170,world,1)
 print('new',n.u.mem_read(world,304).hex())
 for b in [0,14,1,2,1,2]:
  n.call(0x1a330,world,b);print('step',b,n.u.mem_read(world,304).hex())
