# Sloppow Knight replay reproduction

Run these commands from this directory:

```sh
python -m pip install -r requirements.txt
python encode_route.py any-route.json any.bin
python encode_route.py low-route.json low.bin
python verify_native_route.py any-route.json
python verify_native_route.py low-route.json
```

Place the original challenge ELF at `challenge/verifier` before running the checks.
The function-level checker uses Unicorn to execute the original game functions;
it does not run the CLI decoder or timeout wrapper.

Expected results:

- Any%: input frame 720, finish_tick 719, HP 1, deaths 0.
- Low%: input frame 3129, finish_tick 3128, HP 1, deaths 0; 62 runs, 61 input changes.

For the complete CLI check on Linux x86-64:

```sh
chmod +x challenge/verifier
./challenge/verifier 1 any.bin
./challenge/verifier 1 low.bin
```

Both submitted BIN files were accepted by the server on September 20, 2026.
Leaderboard positions in the writeup refer to that date. This package performs
no network submission and contains no team PIN.
