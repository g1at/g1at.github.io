from native_emulator import Native
import json,struct,sys,time
seq=json.load(open(sys.argv[1]));n=Native();world=n.alloc(512);n.call(0x1a170,world,1)
started=time.time()
for tick,b in enumerate(seq,1):
 n.call(0x1a330,world,b)
 raw=bytes(n.u.mem_read(world,304))
 if raw[0x125]:
  print('NATIVE VERIFIED', 'frame',tick,'finish_tick',struct.unpack_from('<Q',raw,8)[0], 'hp',struct.unpack_from('<i',raw,0xc0)[0], 'deaths',struct.unpack_from('<i',raw,0x120)[0], 'elapsed',round(time.time()-started,2))
  break
else:
 print('NATIVE NOT FINISHED', 'frame',len(seq),'room',raw[0x12c],'x',struct.unpack_from('<i',raw,0x98)[0],'y',struct.unpack_from('<i',raw,0x9c)[0]);sys.exit(1)
