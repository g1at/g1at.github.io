# Sloppow Knight

This is a small platformer with a browser build, a WASM module, and a native `verifier`. The server takes a button replay, not a screenshot or a client-side score. Alongside the ordinary finish challenge, Any% rewards speed and Low% rewards fewer input changes.

I extracted the simulation to search routes. The final Any% replay finishes in **5.992 seconds**; Low% uses **61 moves and 26.067 seconds**. Both showed first place at the last check on September 20, with Low% tied at 61 moves. Those are historical results. Here is the format, the physics, and how the two routes came together.

## The attachment

The README in `sloppow-knight-player.rar` states that the same files serve two KOTH leaderboards and one ordinary jeopardy challenge. It also explicitly gives the server seed: **seed = 1**. Challenge site: [Sloppow Knight KOTH](https://koth.bg2.in/).

| Supplied file | Role in the analysis |
|---|---|
| `index.html`, `app.js` | Local interface, button mapping, fixed-step loop, and rendering calls |
| `pkg/koth_render.js` | wasm-bindgen wrapper |
| `pkg/koth_render_bg.wasm` | 58,120-byte browser-side game simulation module |
| `verifier` | 407,448-byte ELF64 / x86-64 native replay verifier |
| `server.py` | Local static HTTP server, not the scoring backend |
| `textures.js`, `audio.js` | Graphics and audio resources |

Rust source paths and runtime traces are visible in the binary, but the attachment contains no Rust source code. We first used the JavaScript wrapper to identify callable interfaces, then compared WASM behavior against the native ELF. Room geometry can be extracted through `room_json()`; there is no need to infer collision boxes from screenshots.


![The local game. Process screenshots replay the WASM with corrected enemy spawning; The WASM/native differences are explained below.](assets/21-game-start.png)

### Model the two objectives separately

**Any%** minimizes completion time: the native simulation's `finish_tick / 120`. For our standard replays, **Low%** minimizes changes in the input mask, not distance traveled, simulated frames, or the total number of individual button presses.

```text
Per-frame inputs:  2 2 2 10 10 0
Input runs:       (2 × 3), (10 × 2), (0 × 1)
Input frames: 6   RLE runs: 3   Changes: 2
```

Holding one input for 300 frames still forms one Low% run. Any% can therefore spend many direction changes to gain speed, whereas Low% may accept hundreds of extra frames to save one change. **Reducing time while remaining at 61 moves does not increase Low% points**. The next improvement worth points must reach 60 moves or fewer.

Both final routes visit rooms in the same order:

```text
0 → 1 → 2 → 4 → 6 → 7 → 8 → 9 → 10 → 11 → 12 → 13 → 14 → 15
```

Neither room 3, Cellar, nor room 5, Shaft, is entered. The hidden exit on the left of Crossroads places the player near the right side of Depths, providing the foundation for later route compression.




## The BIN replay format

A replay consists of a **26-byte little-endian header** followed by variable-length RLE records. Each record says which button combination to hold and for how many frames. The submitted file contains no instructions for modifying game memory.

![BIN file layout](assets/02_binary.svg)

| Offset | Length | Type | Value used and meaning |
|---:|---:|---|---|
| 0x00 | 4 | bytes | ASCII `KSRP` |
| 0x04 | 2 | u16 LE | Version `1` |
| 0x06 | 4 | u32 LE | Recorded seed, set to `1` |
| 0x0A | 8 | u64 LE | Declared total input frames, such as `720` |
| 0x12 | 4 | u32 LE | Metadata, set to `0`; original meaning unconfirmed |
| 0x16 | 4 | u32 LE | Number of RLE records, such as `374` |
| 0x1A | Variable | records | `ULEB128(duration)` + `u8(buttons)` |

Durations use ULEB128: the low seven bits of each byte hold data, and the high bit indicates another byte follows. For example, 169 encodes as `A9 01`. Holding Right+Dash, mask 10, for 169 frames produces the record `A9 01 0A`. Records are not fixed two-byte structures.

| Bit | Value | Action | Common combination |
|---:|---:|---|---|
| 0 | 1 | Left | 5 = Left+Jump |
| 1 | 2 | Right | 6 = Right+Jump |
| 2 | 4 | Jump | 10 = Right+Dash |
| 3 | 8 | Dash | 14 = Right+Jump+Dash |
| 4 | 16 | Interact / Attack | 26 = Right+Dash+Interact |

The native decoder at `0x192a0` checks the magic, version, truncation, and trailing bytes. Limits are 1 MiB per file, 65,536 records, and 1,000,000 frames per duration; button masks must not exceed `0x1f`. No CRC or content-hash check was found. The field at offset 0x12 should not arbitrarily be called a CRC. The SHA-256 values later in this document identify our output files only.

A subtle point: the native decoder does not use the header seed to select the world seed. The seed passed to `World::new` comes from the verifier's command line. Changing the replay header cannot select a different server world.




## WASM and native disagree

Calling `wasmgame_new`, `wasmgame_set_input`, and `wasmgame_step` directly in Node is better suited to enumeration than driving browser keypresses. Each candidate starts from a known state; after executing inputs, we inspect position, velocity, Dash state, and room ID. Saving and restoring WASM memory avoids replaying from frame one for every branch.

However, completing the browser game does not automatically imply server acceptance. We confirmed that **with seed 1, native room 2 spawns three enemies, while the original browser WASM behaves differently**. Ignoring this discrepancy can produce a route that does not reproduce natively.

The local `patch_wasm.py` adjusts only the enemy-spawn branch in the search model, producing `native_like.wasm`. It neither changes the server nor becomes part of the upload. This local correction is not a proof of full equivalence, so final candidates still pass two further checks.

| Layer | What it establishes | Limitation |
|---|---|---|
| Adjusted local WASM | Fast screening, frame inspection, and broad search | No proof of full native-program equivalence |
| Original ELF machine-code replay | Completion using the real native world initialization and step | The function-level script omits full CLI decoding and timeout logic |
| Server upload verification | Acceptance of the actual BIN, with tick, moves, and historical rank | Other teams' submissions can change the ranking |

On Windows, Unicorn executes the ELF game functions: `World::new = 0x1a170` and `World::step = 0x1a330`. We load the original ELF segments and relocations, supplying stubs for allocation and memory operations. This is not a Python reimplementation of physics. The script reads completion at native world `+0x125`, finish tick at `+8`, HP at `+0xc0`, and deaths at `+0x120`.

### Search state must capture more than the picture

| WASM world offset | Field | Why it matters |
|---|---|---|
| +32 / +36 | x / y | Collision and door position |
| +40 / +44 | vx / vy | Momentum carried across rooms |
| +48 / +64 | facing / Dash direction | Distinct values affecting later velocity updates |
| +52 / +56 | coyote / jump buffer | Delayed and automatically triggered jumps |
| +60 / +68 | Dash / cooldown | Dash and speed-preservation timing |
| +84 / +112 | air / RNG | Ground/air speed branches and later random spawns |

These offsets use local WASM `base = g + 8`; they are not native world offsets. One real mistake was deduplicating with only `buttons & 12`, merging states with different facing and discarding a useful braking route. Correctness requires considering the full input history, facing, coyote state, and world state.




## Building speed with Dash reversals

The game updates at 120 Hz. Values below use simulation coordinates, without forcing a conversion to screen pixels. The player's collision box is 600 wide and 900 high. Ordinary directional ground movement is roughly limited to `|vx| ≤ 52`; gravity adds 30 each frame, a normal jump sets `vy = -480`, and a spring sets `vy = -720`. Dash lasts 18 simulation steps and has a 36-step cooldown. [S2,S6]

![Opening Dash reversal speeds](assets/03_dash.svg)

**Starting a Dash in the current direction** adds approximately 165 to existing horizontal velocity before friction. For example, starting from `vx=950` gives about `1114`, rather than resetting velocity to a fixed Dash speed.

**Reversing early during a Dash** includes an update of this form, with the sign matching the new direction:

```text
vx_next = new_direction * (abs(intermediate_vx) + 160)
```

After same-frame friction, a typical reversal adds about 159 to absolute speed. The early reversal window corresponds to an internal Dash count of at least 13. Alternating directions shortly after starting a Dash can push ordinary movement into the thousands. This relationship cannot be extended to arbitrary late reversals: the latter half introduces delayed turning and braking.

For example, the final route's third endgame Dash starts from `vx=1316`. It reaches 1480 on frame 699, then reverses on frames 700, 701, 703, and 704, ending at 2115. Frame 702 continues holding Right. This is the actual replay timing, not unconditional reversal every frame.

### High speed alone is insufficient

Directional ground input clamps velocity. Directional air input, neutral ground coasting, and Dash expiration take different branches. The `air` flag at Dash expiration can immediately reduce a four-digit velocity to 52. Doors also reset position while retaining some movement state. A search objective cannot simply favor larger x: velocity, height, air/ground state, and remaining cooldown all matter.

Jump, Dash, and Interact also depend on rising input edges. Holding a button does not mean pressing it afresh every frame. This is especially important for Low% counting and switch activation.




## Coyote jumps and landing without losing speed

### Coyote-jump state survives leaving a platform

Most platform games allow only a brief grace period for jumping after leaving a ledge. Here, when `air=0` and `coyote>0`, the world update does not enter the airborne branch; coyote countdown itself occurs in the `air=1` branch. A player can therefore walk off a platform and fall while retaining `air=0,coyote=7` until a jump is actually pressed.

The state flag has become detached from geometric position. Both native code at `0x1a73c-0x1a76a` and WASM support this observation. Neutral input in this state loses only 8 horizontal speed per frame; directional input can invoke ordinary ground clamping. The final route coasts off the platform before jumping, preserving upward velocity for the next room.

### Landing must match both frame and coordinate

![Exact-contact update order](assets/05_contact.svg)

The relevant order is: update jump buffer → update Dash horizontal velocity and decrement its counter → if Dash expires, clamp using the old air flag → process Jump → perform world collision → write ground-contact state.

| State or timing | Outcome |
|---|---|
| Start with air=0, Dash=1; press Jump that frame | Velocity first clamps to 52, then the jump occurs; too late |
| Jump with Dash=2 or earlier | Establishes airborne state before expiration, avoiding the ground clamp |
| Start with air=1, Dash=1; feet contact the platform exactly after expiration | Can preserve high speed and gain air=0, coyote=7 |
| Contact one frame early | The next expiration reads air=0 and clamps speed |
| y is 1 unit above the target | A later gravity-driven landing triggers a different clamp path |

The room 13 platform surface is at `y=-1500`. With a 900-high player, the top-left coordinate must be exactly **y=-2400**. Exact contact at `vy=0` avoids the "new vertical landing" clamp branch. This is a precise condition, not a general ability to preserve speed on any landing.

Mechanism tests used synthetic states to isolate branch ordering and compare native/WASM behavior. Those states were not submitted replays. The final file must reach them from the real seed-1 starting state using ordinary inputs.




## Connecting the route

This table gives the **number of inputs already executed upon entering each room** in the two final replays. The start is frame 0; the last row gives completion input counts, not official finish ticks. The first 596 Any% frames handle the route, enemies, switches, and entry to Spring Vault. The remaining 124 complete rooms 13-15.

| ID / Room | Any entry frame | Low entry frame | Route role |
|---|---:|---:|---|
| 0 Foyer | 0 | 0 | Establish initial jump and Dash state |
| 1 Hub | 34 | 216 | Take the upper route into Barracks |
| 2 Barracks | 93 | 535 | Fight the native seed-1 enemy configuration |
| 4 Crossroads | 140 | 729 | Use the hidden left exit |
| 6 Depths | 221 | 1059 | Spawn near the exit for a quick transition |
| 7 Sanctum | 237 | 1066 | Continue the main route |
| 8 Zigzag Ascent | 292 | 1170 | Link platform movement and Dash state |
| 9 Pit Gauntlet | 329 | 1394 | Cross the pits |
| 10 Tower Ascent | 387 | 1750 | Manage vertical routing and velocity |
| 11 Switch Crossroads | 474 | 1937 | Activate the required switch and enter Arena |
| 12 Arena | 569 | 2469 | Fight and prepare the next room's Dash state |
| 13 Spring Vault | 596 | 2654 | Obtain the spring; the routes then diverge |
| 14 Hollow | 692 | 2744 | Control height above the floor hazard |
| 15 Throne | 709 | 2815 | Use tunneling or climbing for the final room |
| Complete | **720** | **3129** | Native finish ticks: 719 / 3128 |

### Independently optimal rooms do not necessarily compose

Doors change position, but velocity, remaining Dash frames, cooldown, some air/ground state, and current input continue to affect the next room. Arriving one frame earlier after a landing clamps vx to 52 can be much worse than arriving one frame later with four-digit speed.

Low% has an additional boundary cost: continuing the same mask across a door adds no input run. Starting every room by releasing all buttons introduces unnecessary changes. Search and splice boundary states must therefore retain at least position, velocity, air, Dash, cooldown, coyote, jump buffer, previous input, and world information such as switches, enemies, and RNG.




## Any%: two Dashes in the spring room


This section describes the **final 720-frame file**. An earlier successful branch activated the spring at frame 611 and landed at frame 678. The final saved full route uses a different variant, with these events at **612 / 679**. The two timelines must not be mixed.

![Actual Spring Vault trajectory](assets/04_spring.svg)

Room 13 begins at frame 596 with `vx=637, Dash=10, CD=28`. Late-Dash direction changes brake the approach so that the spring activates only after Dash ends. Otherwise, Dash would quickly erase the spring's upward velocity.

| Frame | Key state | Purpose |
|---:|---|---|
| 612 | x3151, y-900, vx0, vy-720, CD12 | Actually acquire the spring's vertical velocity |
| 625 | x3515, y-7530, vx52, CD0 | Accelerate right for 13 frames while cooldown expires |
| 626-643 | First Dash, ending at vx-358 | Freeze height and establish leftward velocity |
| 644-661 | Hold Left in free fall for 18 frames | Reach y-2400, vx-412, CD0 |
| 662-679 | Second Dash with early reversals | Touch the first platform on its last frame at vx1358 |

During the spring's collision-free ascent, vertical displacement after t ordinary movement frames is `-15·t·(47-t)`. At t=13, y moves from -900 to -7530. The 18 Dash frames zero vy and freeze height. The following 18 gravity frames add `15·18·19 = 5130`, giving exactly `-7530 + 5130 = -2400`.

The second Dash starts leftward, then uses early reversals to increase absolute speed and finish facing right. At frame 679, the player first touches the first one-way platform as Dash changes from 1 to 0, producing `x9150,y-2400,vx1358,air0,coyote7`. The ballistic calculation, horizontal position, and update order all align on that frame.




![After input 679: exact platform contact, with horizontal velocity still at 1358.](assets/22-spring-replay.png)

## Any%: the final two rooms

After exact contact, coast neutrally for 8 frames. Press only Jump on frame 688 to retain most horizontal velocity, then hold Right in the air. Room 14 begins at frame 692 with `vx=1298, vy=-360, Dash=0, CD=5`.

![Actual trajectory through the last two rooms](assets/06_finale.svg)

**Hazard constraint.** Room 14's floor hazard starts at x3000 with its top at y=-500. The player is 600 wide and 900 high, so the feet must rise safely before horizontal overlap begins. Excessive entry speed with insufficient upward velocity can hit the hazard sooner than a slower route.

Continue right until frame 698 reaches `vx=1316,y=-2430`. Start the third Dash on frame 699. Its first six inputs are `10,1,2,2,1,2`, reaching vx2115 at frame 704 and entering Throne at frame 709 with vx2110.

### Crossing the first wall between collision endpoints

The first wall spans x7000..8500. Pressed against its left side, the player's left coordinate is `7000-600=6400`. If an update's endpoint reaches the wall's right edge or beyond, the collision code does not fully sweep the intervening path. Crossing both the wall width and player width requires an actual horizontal displacement of at least **1500+600=2100** in that step. Friction still acts on starting vx, so a starting velocity of 2100 alone does not guarantee crossing.

At frame 712, the player is still at x6400 with vx2107, Dash4, and air0. Pressing Jump on frame 713 gives a horizontal displacement of 2106, putting the left coordinate at **8506**, while y becomes -1380 and air1. The jump also establishes airborne state before Dash expires, preventing a clamp to 52 on frame 716.

The second wall leaves a gap underneath, which the route passes through. Completion occurs after the 720th input, but the native finish tick is 719: `719 / 120 = 5.9916666667`. The server displays **5.992 seconds**. Calculating 720/120 as 6.000 seconds would be one frame off from official timing.




![After input 713: x = 8506, beyond the first wall.](assets/23-wall-replay.png)


![Finished after input 720. The local HUD shows 6.00 s; native finish tick 719 gives the official 5.992 s.](assets/24-finish-replay.png)

## Low%: every input change counts

![Low% input-run distribution](assets/07_low_runs.svg)

The final Low% replay contains 3129 per-frame inputs but only **62 maximal runs of identical masks**. It finishes within the final run, giving 61 official changes. Strictly, the native calculation compares finish tick with cumulative record durations. Arbitrary files containing extra records or redundant runs cannot always be interpreted as "header record count minus one." [S4,S8]

### Four useful forms of compression

1. **Carry one mask across room boundaries.** For example, `10×187` spans rooms 0→1, `10×358` spans 1→2, `18×219` spans 2→4, and `6×305` spans 9→10. Passing a door does not itself require a new run.
2. **Combine simultaneous actions in one mask.** Mask 26 combines Right, Dash, and Interact; 22 combines Right, Jump, and Interact. This merges held-button states without turning edge-triggered actions into per-frame repetition.
3. **Deliberately trade time for fewer changes.** Room 11 includes `26×337`. Long waits and movement are acceptable when they save input runs.
4. **Treat fresh rising edges as a resource.** Room 13's final mask6 begins on frame 2743 and continues into room 14, with Jump already held. Removing a run in the previous room can also remove a jump edge needed in the next one.

Low% still uses Dash reversals at selected points, but does not spend input changes as freely as Any%. Maximizing instantaneous velocity usually does not minimize moves.

### Combat and switches consume the same input budget

The final Low% route drops from HP3 to HP2 on frame 693 in Barracks, and to HP1 on frame 2640 in Arena, with no deaths. Required switch index 2 activates on frame 2133 from a fresh Interact edge. The player is then at top-left x3324, y-12400, while the switch center is (2500,-12200); the check uses the player's center and a Manhattan-distance range of 1400.

Simply holding Attack while approaching a switch is therefore unreliable. Entering range without a new edge does not activate it automatically. Geometry, button edges, and RLE boundaries must be planned together.




## Low%: overlapping platforms in the final room

![Low% trajectory through the final room](assets/08_low_route.svg)

The line tracks the player's top-left corner. Its 600-unit width explains why the final x21946 already overlaps the finish region starting at x22500.

The two columns of one-way platforms in Throne are separated by a 500-unit gap, but the player is 600 units wide. Keeping the left coordinate in **(2400,2500)** lets the collision box overlap both columns horizontally. In the observed simulation, one-way platform handling during ascent also places the player onto higher platform surfaces, restoring ground-contact state.

For example, frames 2842, 2851, 2857, and 2863 move y to -3900, -6400, -8900, and -11400. These single-frame displacements exceed ordinary vy integration while vy remains negative. The route uses actual upward repositioning by collision handling; describing it as a normal physical "double jump" would be misleading.

| Input after entering room15 | Duration | Absolute end frame | Purpose |
|---|---:|---:|---|
| 2 (Right) | 21 | 2836 | Extend the input already held on entry at no new-run cost |
| 4 (Jump) | 13 | 2849 | Reduce horizontal travel and enter the overlap zone |
| 1 (Left) | 4 | 2853 | Release Jump to prepare another rising edge |
| 6 (Right+Jump) | 13 | 2866 | Second jump, raising the next starting point |
| 10 (Right+Dash) | 18 | 2884 | Approach the first tall wall and release Jump |
| 6 (Right+Jump) | 58 | 2942 | Third jump, passing over the first wall |
| 1 (Left) | 18 | 2960 | Drop from the middle platform and reposition |
| 10 (Right+Dash) | 169 | 3129 | Pass under the second wall and reach the finish |

This 314-frame tail adds only 7 input runs. At frame 2900, the player reaches x7276, y-15930, clearly above the first wall's top at y=-13000. Low% therefore takes an **over-the-wall route**, unlike Any%'s high-speed endpoint tunneling.

This tail refinement reduced the previous 3169-frame route to 3129 frames, saving 40 frames while remaining at 61 moves. It improved time, not Low% points.




## Searching, and the branches that failed

![Recorded Any% progress](assets/09_progress.svg)

The search combined action-macro enumeration, frame-level beam search, local input replacement, run-duration adjustment, and collection of room-boundary states. Any% ranks candidates by completion frame. Low% prioritizes added input runs, using time for feasibility or as a secondary metric at equal cost.

```text
frontier = {real starting state or real replay prefix}
for each search layer:
    Expand allowed buttons/durations; run deterministic simulation
    Discard states that violate the current task constraints
    Preserve differences in world state, input history, and facing
    Select the next layer by objective and physical-state diversity
    On completion: reconstruct full input → native replay → encode → server
```

The main breakthrough from 794 to 720 frames was not merely increasing search width. It was discovering a composable sequence: real spring launch → exact platform contact on the last Dash frame → retained coyote state → delayed jump → high-speed crossing of the first wall. The final two-frame improvement came from jumping early enough in the last room to avoid the ground-speed clamp at Dash expiration.

| Direction that did not yield a better result | Finding, not an optimality proof |
|---|---|
| Compare position while discarding facing | Incorrectly merges states with different futures and loses valid braking paths |
| Faster room14 entry | Can hit the hazard before rising enough |
| Reduce Low's final 7 new runs to 6 | Two bounded searches found no complete route; two jumps were too low in the tested families |
| Save one run locally in room13 | Can remove room14's required Jump edge and make the full route fail |
| Death or checkpoint transitions | Tested branches did not beat the final zero-death route |
| Re-encode the same Low trajectory | Still needs 62 runs; this does not bound all possible trajectories |

Later searches found prefixes entering Spring Vault at frame 596 with vx957, later platform contacts with speeds up to about vx1789, and prefixes retaining HP2. None became a faster, fully verified complete replay. **720 frames and 61 moves are the best verified results found here, not mathematical lower bounds.**




## Encode and verify the replay

The package's `repro/` directory contains both final per-frame JSON files, the encoder, and the native function-level verification script. Obtain the original ELF from the challenge attachment and place it at `repro/challenge/verifier`. Run the following commands from `repro/`. Encoding creates replay files but does not automatically submit anything to the website.

```powershell
python encode_route.py any-route.json any.bin
python encode_route.py low-route.json low.bin
python verify_native_route.py any-route.json
python verify_native_route.py low-route.json
```

Native function-level verification requires `unicorn` and `pyelftools`. On Linux x86-64, the original challenge CLI can also be used. Its command-line seed must be 1:

```bash
chmod +x challenge/verifier
./challenge/verifier 1 any.bin
./challenge/verifier 1 low.bin
```

The encoder's core logic is shown below; the complete file is included in the package. Input JSON is a per-frame array of masks from 0..31, not a sequence of state snapshots.

```python
import struct

def uleb(n):
    out = bytearray()
    while n >= 128:
        out.append((n & 127) | 128)
        n >>= 7
    out.append(n)
    return out

def encode(seq):
    runs = []
    for mask in seq:
        assert 0 <= mask <= 31
        if runs and runs[-1][1] == mask:
            runs[-1][0] += 1
        else:
            runs.append([1, mask])
    data = bytearray(struct.pack(
        '<4sHIQII', b'KSRP', 1, 1,
        len(seq), 0, len(runs)))
    for frames, mask in runs:
        data += uleb(frames) + bytes([mask])
    return bytes(data)
```

The original submission process entered team name Hor1zon on the challenge site, selected the relevant `.bin`, and requested verification. Historical server results were tick719 / moves373 and tick3128 / moves61.




![September 22 rerun: encode both replays and verify the native game functions. Finish ticks are 719 and 3128.](assets/20-notebook.png)

## The complete Low% route and flag

Notation is **mask × duration in frames**. Expanding the following 62 runs in order produces the entire 3129-frame Low% route, not just its final room.

```text
26×79, 6×29, 10×187, 22×18, 10×358, 21×1, 8×1, 22×16,
0×3, 18×1, 4×2, 18×14, 9×1, 18×219, 6×16, 16×1,
5×34, 25×42, 5×33, 24×4, 18×14, 6×18, 10×23, 6×21,
10×208, 6×19, 10×55, 6×32, 10×35, 6×305, 10×27, 6×18,
8×21, 5×15, 8×1, 2×1, 1×1, 6×33, 26×100, 22×69,
9×17, 5×40, 26×337, 6×26, 10×144, 16×1, 8×1, 22×45,
9×1, 2×39, 10×16, 6×24, 10×1, 1×1, 2×68, 4×13,
1×4, 6×13, 10×18, 6×58, 1×18, 10×169
```

The following independent count confirms the distinction between input runs and moves:

```python
import json
from itertools import groupby
seq = json.load(open('low-route.json'))
runs = [(b, len(list(g))) for b, g in groupby(seq)]
assert len(seq) == 3129
assert len(runs) == 62
assert sum(a != b for a, b in zip(seq, seq[1:])) == 61
```

Any%'s 374 runs are better reproduced from `any-route.json` than transcribed manually. The two submitted files have these SHA-256 values:

```text
Hor1zon-anypercent.bin  /  774 bytes
12ce7b91c7498d270dc89e450488cd3264a41c94090dbd3b555440828b1a31e2

Hor1zon-lowpercent.bin  /  158 bytes
1b932654f32668ad2d8e0dc5cd1f243cc978172470d1144206078e7ec38d3b56
```

Both historical first-place verification dialogs displayed the same flag. The saved record does not show a separate second flag:

```text
07CTF{sl0pp0w_kn1ght_>>>_h0ll0w_kn1gh7}
```

The reproduction package's native check executes the real game machine code. The WASM/native comparison above explains how its scope differs from a full CLI check. Historical server acceptance and file hashes together identify the exact results discussed in this writeup.




## Reproduction files

The archive includes both final per-frame routes, their encoded BIN files, the encoder, and a Unicorn-based checker for the original game functions. `data/` contains the room geometry and frame traces used for the plots. Supply the challenge's original `verifier` separately.

The difficult part was connecting the speed tricks into a complete run. A promising intermediate state was useful for experiments; the result still had to reach the finish from the real start and pass the native verifier.
