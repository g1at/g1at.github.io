"""Read only the previously verified NCACHE1 extent from this challenge image.

E01: python carve_from_e01.py --image workstation.E01 --out NCACHE1.bin
Raw: python carve_from_e01.py --image workstation.raw --raw --out NCACHE1.bin
E01 parsing requires dissect.evidence. Original evidence is opened read-only.
"""
import argparse
import hashlib
from pathlib import Path

OFFSET = 3_413_454_848  # Decoded whole-disk logical byte offset, not E01 physical.
LENGTH = 10_316
EXPECTED = 'fa7d7753553d07395baa01f57c46e96ada2e1a9acfbf9d573516dd48e08ba83c'

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--image', required=True, type=Path)
    parser.add_argument('--raw', action='store_true')
    parser.add_argument('--out', type=Path, default=Path('NCACHE1.bin'))
    args = parser.parse_args()
    if args.out.resolve() == args.image.resolve():
        raise ValueError('Output must differ from the input evidence image')
    if args.raw:
        stream = args.image.open('rb')
    else:
        from dissect.evidence.ewf import EWF
        image = EWF(args.image)
        stream = image.open()
    stream.seek(OFFSET)
    extent = stream.read(3 * 4096)
    blob = extent[:LENGTH]
    if len(blob) != LENGTH or blob[:8] != b'NCACHE1\0':
        raise ValueError('This is not the expected NCACHE1 extent')
    digest = hashlib.sha256(blob).hexdigest()
    if digest != EXPECTED:
        raise ValueError('Recovered data does not match the verified challenge blob')
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_bytes(blob)
    print(f'Recovered {len(blob)} bytes at decoded disk offset {OFFSET}')
    print(f'SHA256: {digest}')
    print(f'Remaining extent slack is zero: {not any(extent[LENGTH:])}')

if __name__ == '__main__':
    main()
