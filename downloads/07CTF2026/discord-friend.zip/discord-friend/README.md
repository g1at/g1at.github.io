# Discord Friend — offline reproduction

This directory contains the challenge's recovered encrypted blob and a read-only
solver. The original image, complete installer, and decrypted credential files are
not included. The recovered seed constants are documented in the writeup.

```sh
python -m pip install pycryptodome
python decrypt_ncache.py
```

Expected result:

```text
HMAC-SHA256 verified
07CTF{d0_n07_p1p3_t0_b4sh_3v3r!!!}
```

To carve the same bytes from the original challenge E01:

```sh
python -m pip install dissect.evidence
python scripts/carve_from_e01.py --image path/to/workstation.E01 --out recovered/NCACHE1.bin
python decrypt_ncache.py --blob recovered/NCACHE1.bin
```

The compact public solver authenticates before decryption, reads only the expected
flag member in memory, and does not write a plaintext archive. It requires the
original image's machine ID, which is set as the default for this CTF artifact.
