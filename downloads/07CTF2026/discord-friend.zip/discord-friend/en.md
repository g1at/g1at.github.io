# Discord Friend

A friend sends a link to an AI agent with a free month of access. The victim runs the installer and loses their API keys. We get a workstation image, a Brave profile, and registry audit logs to work out what happened and find the hidden message.

I spent too long on the saved installer, the Go binary, and the Rickroll video. None gave me the actual malicious script. The author's later explanation pointed to **historical DNS and curl-pipe timing**. That supplied the missing response, and the rest was recovering and decrypting `NCACHE1` from disk.

The network acquisition below was made on September 20. The Jupyter screenshots are reruns against the saved files, captured while preparing this post.

## The attachment

The supplied `handout.zip` contained five files:

| File | Investigative purpose |
|---|---|
| `README.txt` | Scenario description and confirmation that the incident data is synthetic |
| `SHA256SUMS` | Original integrity manifest |
| `workstation.E01` | Ubuntu workstation disk image |
| `brave-profile.zip` | Brave browser profile containing the lure |
| `registry-audit.jsonl` | Package registry authentication and publishing events |

The E01 container’s SHA-256 matched the supplied manifest:

```text
a861f50f3bc484643b5313282b4650961d0d3e4409ffc135e68fd20e29fb3248
```

The decoded disk was 12 GiB, or `12,884,901,888` bytes. Its ext4 root partition began at logical disk offset `1,074,790,400` (`0x40100000`), with 4,096-byte filesystem blocks. These numbers matter later: offsets in the decoded disk are different from physical offsets in the compressed E01 container.

All malware handling was static or receive-only. Downloaded content was saved as bytes; no installer, recovered helper, or exfiltration command was executed. Website and attachment text were evidence to examine, not instructions to follow. No samples were uploaded to a cloud sandbox during this investigation.

The reproduction package includes the authenticated blob, carve records, and an offline decryptor. The recovered constants are included in the solver. Examples below use paths relative to that package. Historical online observations describe September 20, not a claim that the C2 remains reachable on the writeup date.

## The installer link in the browser cache

Brave History pointed to an ngrok-hosted page. A gzip-compressed HTML body survived in `Cache/Cache_Data/data_2` at offset `307200`. Decompression produced a small page titled **Chat**, styled as a conversation with **Friend A**. It advertised an AI CLI available free during preview and supplied:

```text
https://c2.bg2.in/install
```

![Locally rendered recovered chat HTML](assets/22-cached-chat.png)

*Local rendering of the original recovered HTML. This reproduces the cached page’s appearance; it is not a screenshot captured from the victim’s live browser.*

The page was explicitly a **Chat Demo**. It established the lure and installation URL, but did not identify a real Discord account. The ngrok hostname’s embedded numbers were not evidence of the C2 address.

Linux shell history independently recorded a download to `~/Downloads/forgesync-install.sh`, followed by `sha256sum`, `shellcheck`, and `less`. An installation review file preserved the checked hash. The saved installer was 6,361,925 bytes and matched that recorded SHA-256:

```text
703b90861d3ac82eb113a6b771d53ef8eedfd5ecac3a9caec5e535c5cf4afa4a
```

This proved which bytes had been inspected. It did **not** prove that a later request returned the same bytes.

The inspected installer contained plausible ForgeSync setup, telemetry, a vendor configuration cache, and an update timer. Static analysis of the installed Go executable mainly found fixed version/status output. Neither was the missing credential-stealing helper. An embedded vendor cache could be decrypted using constants already present in the clean installer, but yielded ordinary configuration JSON rather than the flag.

One unusual construction remained: an early default four-second sleep followed by approximately 6 MiB of comments. It was excessive padding for an installer, and ultimately explained why inspection and execution could receive different content.

Two limits belong in the reconstruction. First, sudo logs recorded `/usr/bin/bash`, but did not preserve the complete original pipeline. The precise victim command is therefore not directly recovered from those logs. Second, Brave’s relevant History timestamp was `2026-09-18 22:18:04.303321 UTC`, later than the Linux infection events that morning. The cached content corroborates the URL; the mismatched browser clock cannot establish the exact ordering across both systems.

## A clean installer, but suspicious services

The system journal recorded a suspicious pair of units: `network-cache.path` and `network-cache.service`. Historical ext4 metadata identified their components:

| Component | Historical inode | Original size | Original filesystem block |
|---|---:|---:|---:|
| `systemd-network-cache-generator` | 264123 | 905 bytes | 570971 |
| `/usr/local/libexec/network-cache` | 264124 | 2,240 bytes | 570972 |

The generator’s full path was `/usr/local/lib/systemd/system-generators/systemd-network-cache-generator`. Both original data blocks were unallocated and entirely zero. Recovering their inode records was not equivalent to recovering their code.

The strongest surviving sequence occurred when Alice started a `constellation` release. The script `/home/alice/src/constellation/tools/release.sh` created `.release-running` immediately before logging its start; milliseconds after that log, systemd started the suspicious service, and three credential-related access times changed in quick succession. The logger's timestamp is preserved, while the precise instant of the preceding marker creation is not.

![UTC incident timeline](assets/03-timeline-en.svg)

*Timeline reconstructed from journal records, filesystem metadata, and registry audit events. All displayed incident times are UTC on September 18, 2026.*

| UTC time | Observation |
|---|---|
| 08:12–08:13 | Installer downloaded and inspected |
| 08:14:16 | Two suspicious scripts created |
| 08:14:17.037232 | `network-cache.path` started |
| 09:29:00.625727 | Release process announced its start |
| 09:29:00.628488 | `network-cache.service` started |
| 09:29:00.648–.650 | Credential, signing-key, and environment-file access times changed |
| 09:29:00.681 | Recovered encrypted blob’s historical modification time |
| 09:29:00.932232 | Helper logged retirement of its one-shot components |
| 09:29:01.446371 | Service finished |
| 09:48–09:52 | External token authentication, abnormal publication, and tag update |

At this stage, the access times supported a reading hypothesis, but did not establish which process read each byte or prove successful network delivery. Later decryption strengthened that evidence: the recovered archive contained byte-identical copies of all three files.

The registry audit provided a separate consequence. The local publish token’s SHA-256 prefix was `aa44319a8959`, matching successful external authentication, publication of `constellation@2.7.4-hotfix.1`, and a `latest` tag update. A mirror-read token instead produced fingerprint `dbef6401d332` and matched a failed external login. The fingerprint is the first 12 hexadecimal characters of SHA-256 over the original UTF-8 token string. The audit’s addresses and credentials are synthetic exercise data; they are not attribution to real people.

## The hint: historical DNS

During the investigation, the domain’s root displayed a Rickroll and the public `/install` route returned a 404 response. That was a statement about the currently reached endpoint, not proof that every historical server was gone.

The author’s explanation directed attention to DNS history. The [DNS History record for `c2.bg2.in`](https://dnshistory.org/historical-dns-records/a/c2.bg2.in) showed an A record dated September 18, 2026:

```text
c2.bg2.in  →  34.56.224.40
```


The successful capture addressed `https://34.56.224.40/install` with the IP as the HTTP Host and no TLS SNI. Its certificate named `c2.bg2.in`, so normal IP-name verification would fail. Certificate verification was disabled only for this anonymous forensic acquisition, and the certificate was preserved. This did not authenticate the peer cryptographically; identification also depended on the historical record, installer comparison, and subsequent agreement with disk evidence.

An older hosts-file version in the image mapped `c2.bg2.in` to `10.0.2.2`, alongside the exercise’s `.test` service names. That helps explain the synthetic environment, but the internal fixture address was not the public origin recovered through DNS history.

The investigation machine also used a Mihomo TUN. Earlier domain-based responses came through a different path, so a Cloudflare 404 could not reliably be attributed to the historical origin itself. The successful receive-only capture selected the WLAN interface for its individual socket without changing global routes or proxy settings.

## Pretending to curl | bash

The hint linked Luke Spademan’s [“The dangers of curl | bash”](https://lukespademan.com/blog/the-dangers-of-curlbash/). The relevant idea is that a server can distinguish response consumption patterns: a process saving bytes to disk generally continues reading, whereas an interpreter may pause while executing an early command. Enough subsequent padding can fill intermediate buffers and make that pause observable to the sender.

This installer placed the following line at roughly 4.9 KB, before its large comment region:

```bash
sleep "${FORGESYNC_MIRROR_DELAY:-4.0}"
```

In a streamed execution, the shell can encounter that sleep before it has consumed the remainder. The pipe and network buffers eventually impose backpressure. The server can then select a different tail. That mechanism explains why running inspection tools on a previously saved file does not establish what a fresh streamed request will contain.

![Normal reading compared with paused reading](assets/02-timing-en.svg)

*Conceptual explanation of the observed response selection. Buffer sizes and server-side thresholds are not claimed to have been recovered from server source.*

We simulated the relevant input condition directly in a socket receiver. The receiver saved HTTP data, paused reads, resumed, and saved the remainder. It did not interpret the response. The successful acquisition, beginning at `2026-09-20 12:39:04 UTC`, recorded:

| Parameter | Captured value |
|---|---|
| Peer | `34.56.224.40:443` |
| Requested socket receive buffer | 65,536 bytes |
| Pause point | After 11,112 received HTTP bytes |
| Pause duration | 8 seconds |
| HTTP body length | 6,361,925 bytes |
| Downloaded code executed | False |

The 11,112-byte pause point includes 249 bytes of HTTP headers, leaving 10,863 body bytes received before the pause. It is a receiver observation, not an offset of a shell instruction.

The receiver paused its reads; it never ran the response. The reproduction files below contain the blob and recovered constants, so the decryption does not need the server.

A previous paused attempt still received the normal installer. Both interface selection and pause placement changed before the successful attempt; these observations do not isolate the numerical contribution of proxy buffering. Nor was the server implementation recovered. The directly established result is that the successful paused read obtained a malicious variant whose contents agree with the erased artifacts.

The normal response matched the installer in the image byte for byte. The malicious response had the same total length and ETag but a different SHA-256:

```text
Clean:      703b90861d3ac82eb113a6b771d53ef8eedfd5ecac3a9caec5e535c5cf4afa4a
Malicious:  46afd7e874c29220ea034e84a01eaaf037435787def753fc2aa41bd8029dcba7
```

Their first differing byte was at zero-based body offset `6,296,745`. The malicious response replaced tail padding with additional installation code. Equal length and ETag were therefore inadequate comparison checks.


![Comparing the responses saved on September 20: identical lengths, with the malicious tail starting at byte 6296745.](assets/20-notebook.png)

## Finally, the malicious scripts

The extra tail contained two Base64 strings written to the generator and helper paths. Decoding those strings as data yielded a 905-byte generator and a 2,240-byte helper—exactly the historical lengths recovered from ext4.

Their SHA-256 values were:

```text
Generator: 909bcc6a111e5402e31a6dfc312a7db09c887c5de0a6f48f0f2cc4b8e4b60e58
Helper:    86f1231e51bfc80c3ae0a2638754bd9e88d879a790c19b7f167903ef6593ccdb
```

The generator emitted a path unit watching `/home/alice/src/constellation/.release-running`, with `Unit=network-cache.service`. The service used `Type=oneshot` and `ExecStart=/usr/local/libexec/network-cache`. These definitions explained the nearly immediate service start after the release marker appeared.

The helper read a hexadecimal secret from `/run/.systemd-netseed` and packaged four paths into a ustar archive:

```text
home/alice/.config/forgehub/credentials.json
home/alice/.config/cosign/release.key
home/alice/src/constellation/.env.production
dev/shm/.ncache-result
```

It generated a salt and IV, derived a key using the workstation’s machine ID, encrypted the tar archive, and wrote a staged `/var/tmp/.net-cache-$$` file. The default upload destination in the script was `https://telemetry.forgesync.test/v1/diag`. The helper then removed the staging file, seed, and result, logged the retirement message, and shredded both persistent scripts using two passes plus a final zeroing pass.

The recovered source explains both kinds of residue: the script blocks were zeroed, while the staging file was unlinked without the same shredding operation. Service logs show execution reached the cleanup stage, and the encrypted package establishes its contents. No captured outbound transaction is available here to prove every byte received by the remote endpoint.

The helper uses octal escapes for the magic string, with a comment explaining that this avoids a second literal carving hit. Consequently, searching only script text for the ASCII word `NCACHE1` could miss its format writer.

## Back to the image: recover NCACHE1

The decisive file had actually been recovered earlier as `85122-461.bin`, but its role was overlooked. Revisiting it after the hint revealed the eight-byte header `NCACHE1\0`. Correcting that omission matters: the erased scripts were unavailable from their blocks, but malware-generated evidence was still present in the image.

Historical inode **85122** in journal commit **461** had size **10,316** and an extent covering filesystem blocks **570963–570965**. Its modification time, `09:29:00.681 UTC`, fell between the credential accesses and cleanup log.

That inode was later reused for `/etc/hosts`. Inode numbers identify reusable filesystem records, not permanent identities; applying today’s filename to yesterday’s record would mislabel this blob. The relevant evidence is the historical inode version, its extent, size, and transaction context.

The logical disk offset is:

```text
partition start + filesystem block × block size
= 1,074,790,400 + 570,963 × 4,096
= 3,413,454,848
```

Read the E01 through an EWF-aware decoder, then seek within the decoded stream. Do not apply this offset directly to the physical `.E01` file. An equivalent read-only carve with the Dissect libraries is:

```python
from pathlib import Path
from dissect.evidence.ewf import EWF
from dissect.volume.disk import Disk
import hashlib

image = EWF(Path("workstation.E01"))
disk = Disk(image.open())
partition = disk.partitions[0]
assert partition.offset == 1_074_790_400
stream = partition.open()
stream.seek(570_963 * 4096)
extent = stream.read(3 * 4096)
blob = extent[:10_316]
assert blob[:8] == b"NCACHE1\0"
assert not any(extent[10_316:])
assert hashlib.sha256(blob).hexdigest() == (
    "fa7d7753553d07395baa01f57c46e96ada2e1a9acfbf9d573516dd48e08ba83c"
)
Path("NCACHE1.bin").write_bytes(blob)
```

This direct reread matched the earlier journal-based recovery exactly. The unused remainder of the three-block extent was all zero. The size and magic alone suggested a structured container; the recovered helper supplied the actual specification.

![NCACHE1 structure and carving provenance](assets/04-blob-en.svg)

*Rendered binary-layout and hex evidence excerpt. The disk offset belongs to the decoded disk, not to the E01 container’s physical byte positions.*

## The format and the key

The format was:

| Offset | Length | Meaning |
|---:|---:|---|
| 0 | 8 | Magic `NCACHE1\0` |
| 8 | 4 | Big-endian ciphertext length: `0x2800`, or 10,240 |
| 12 | 16 | Random salt |
| 28 | 16 | AES counter IV |
| 44 | 10,240 | AES-256-CTR ciphertext |
| 10,284 | 32 | HMAC-SHA256 over all preceding bytes |

The total length check is `8 + 4 + 16 + 16 + 10240 + 32 = 10316`. The final zero in the magic is a byte, not the printable characters backslash and zero.

The installer hid the seed as two 32-byte hexadecimal values:

```text
p0 = 24a5fc36c1a0a128a68ff8b3d01a4ef990f13a555dc5e0bd3e2cb4d4a58bc51f
p1 = 729a6f698dfe8675acdd0f1ef04ed181a7add7bc5d06082fbad9c1d5754c3298
```

XORing their decoded bytes reproduced the seed written to `/run/.systemd-netseed`:

```text
563f935f4c5e275d0a52f7ad20549f78375cede900c3e89284f57501d0c7f787
```

The machine ID from the image’s `/etc/machine-id`, with its newline removed, was `2e1481aad781941b9f4d4b1da0308022`. The blob supplied:

```text
salt = 7488222b0e2cb592852521e36a3b6795
IV   = 876d09f1a918fbd9ecfed2aad75c199b
```

The helper’s key derivation was plain SHA-256 of an exact byte concatenation:

```text
key = SHA256(seed_raw
             || machine_id_ASCII
             || ASCII("|forgesync-network-cache-v2|")
             || salt_raw)
```

The seed and salt must be decoded from hex; the machine ID remains its 32 ASCII characters. There is no newline or extra delimiter beyond the literal context string. Using hex text everywhere produces the wrong key.

![Key derivation and authenticated decryption](assets/05-crypto-en.svg)

*Diagram of the byte-level derivation recovered from the helper. Values are transcribed from the captured payload and image evidence.*

The resulting 32-byte key was:

```text
d01b8e579499eec454c10f97e9554ea886270e1ba3219163335697631ce51eb3
```

The script uses this same key for AES and HMAC. The computed HMAC matched the final 32 bytes exactly:

```text
897ae66e90d8c5b6b234f19a6f5bbc51dac961a367946b21745b7c7b2a5cd536
```

That match is a stronger check than recognizing a plausible tar header or flag string. It verifies that the recovered blob, seed, machine ID, salt, and interpretation of the authenticated fields agree. Only after this check did the offline analysis decrypt and parse the archive.

## Decrypting the flag

The following core example performs no network access or payload execution. It requires PyCryptodome. It extracts only the expected regular-file member in memory, rather than unpacking arbitrary archive paths onto disk.

```python
from pathlib import Path
import hashlib, hmac, io, struct, tarfile
from Crypto.Cipher import AES

blob = Path("NCACHE1.bin").read_bytes()
assert blob[:8] == b"NCACHE1\0"
length = struct.unpack_from(">I", blob, 8)[0]
assert len(blob) == 44 + length + 32

p0 = bytes.fromhex("24a5fc36c1a0a128a68ff8b3d01a4ef990f13a555dc5e0bd3e2cb4d4a58bc51f")
p1 = bytes.fromhex("729a6f698dfe8675acdd0f1ef04ed181a7add7bc5d06082fbad9c1d5754c3298")
seed = bytes(a ^ b for a, b in zip(p0, p1))
machine = b"2e1481aad781941b9f4d4b1da0308022"
salt, iv = blob[12:28], blob[28:44]
key = hashlib.sha256(
    seed + machine + b"|forgesync-network-cache-v2|" + salt
).digest()
tag = hmac.new(key, blob[:-32], hashlib.sha256).digest()
assert hmac.compare_digest(tag, blob[-32:]), "Authentication failed"

plain = AES.new(
    key, AES.MODE_CTR, nonce=b"",
    initial_value=int.from_bytes(iv, "big")
).decrypt(blob[44:-32])
with tarfile.open(fileobj=io.BytesIO(plain), mode="r:") as archive:
    member = archive.getmember("dev/shm/.ncache-result")
    assert member.isfile() and 0 < member.size < 4096
    result = archive.extractfile(member).read()
print(result.decode("ascii"))
```

An empty PyCryptodome nonce and the full 128-bit big-endian IV reproduce the counter layout used by the helper’s OpenSSL command. CTR preserves length, so the decrypted archive was also 10,240 bytes. Its SHA-256 was:

```text
6ccffbfb1a02050ad196e1ecd0eadbc60fe6b06b2f0434476300dfa7420df687
```

| Decrypted member | Size |
|---|---:|
| `home/alice/.config/forgehub/credentials.json` | 283 bytes |
| `home/alice/.config/cosign/release.key` | 165 bytes |
| `home/alice/src/constellation/.env.production` | 204 bytes |
| `dev/shm/.ncache-result` | 35 bytes |

The first three members matched their original image files byte for byte. The final member contained:

```text
07CTF{d0_n07_p1p3_t0_b4sh_3v3r!!!}
```


![JupyterLab rerun: inspect the NCACHE1 header, verify the HMAC, and recover the flag.](assets/21-decryption.png)

For the packaged implementation, run from the package directory:

```text
python -m pip install pycryptodome
python decrypt_ncache.py
```

If PyCryptodome is already installed, skip the installation command. The verified environment used PyCryptodome 3.18.0. To repeat the carve from the original E01 using the supplied helper, run:

```text
python -m pip install dissect.evidence
python scripts/carve_from_e01.py --image path/to/workstation.E01 --out recovered/NCACHE1.bin
python decrypt_ncache.py --blob recovered/NCACHE1.bin
```

Add `--raw` when supplying a decoded raw disk image. The packaged helper reads the known whole-disk logical offset and verifies the recovered hash; it is specific to this challenge. The partition-aware example above additionally uses `dissect.volume`, which must be installed if reproducing that example rather than the supplied helper.

The public solver uses the seed constants recovered above, checks the HMAC, and reads only the flag member in memory. It does not save a plaintext credential archive.

## Detours

Several leads were reasonable but lacked the essential evidence.

The Rickroll’s `secret.mp4` name suggested steganography. Container, media-packet, frame, and audio checks produced no valid flag. I eventually stopped following that lead and returned to the installer.

The saved installer and Go ELF were tempting reverse-engineering targets, but they belonged to the benign response path. A cloud sandbox analyzing only those files could never reconstruct secrets absent from its input. The malicious response was the missing acquisition target.

Broader disk searches also had limits. Ext4 journal metadata preserved file histories, not an automatic backup of every overwritten data block. Repeatedly carving the two zeroed script extents could not recover their original text. The surviving encrypted staging blob required recognizing a different artifact and bringing in key material from outside the image.

Finally, public 404 responses were overinterpreted early on. Historical DNS was the small OSINT step that connected the present domain to the useful origin. Author-profile research and guesses about alternate paths added little once that concrete record was available.

The final chain rests on mutually consistent checks: the original installer hash, a separately captured malicious response, decoded helper lengths matching historical inode sizes, a blob carved twice from the same extents, a valid HMAC, and decrypted credentials identical to the image. Those checks support the flag without requiring malware execution, guesses about hidden text, or claims of network evidence that was never captured.

## References and scripts

- [07CTF](https://ctf.0bscuri7y.in/)
- [DNS History: c2.bg2.in](https://dnshistory.org/historical-dns-records/a/c2.bg2.in)
- [The Dangers of curl | bash](https://lukespademan.com/blog/the-dangers-of-curlbash/)
- [Yusuf Tas's writeup of the same challenge](https://yusuftas.net/posts/07ctf-discord-friend-writeup/): a style reference while preparing this post. The measurements, scripts, and screenshots here come from the saved local solve.

The reproduction archive contains `NCACHE1.bin`, `decrypt_ncache.py`, the E01 carving script, and the carve records. Supply the original challenge image separately. The complete malicious installer and decrypted credential files are not part of the website download.
