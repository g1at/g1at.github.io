"""Authenticate a recovered CTF NCACHE1 blob and read only its flag member.

No network access, installer execution, or full archive extraction is performed.
The published constants were recovered from the challenge's captured installer.
"""
import argparse
import hashlib
import hmac
import io
import struct
import tarfile
from pathlib import Path
from Crypto.Cipher import AES

P0 = bytes.fromhex('24a5fc36c1a0a128a68ff8b3d01a4ef990f13a555dc5e0bd3e2cb4d4a58bc51f')
P1 = bytes.fromhex('729a6f698dfe8675acdd0f1ef04ed181a7add7bc5d06082fbad9c1d5754c3298')


def recover(path, machine_id):
    blob = path.read_bytes()
    if len(blob) < 76 or blob[:8] != b'NCACHE1\0':
        raise ValueError('Invalid NCACHE1 header')
    length = struct.unpack_from('>I', blob, 8)[0]
    if len(blob) != 44 + length + 32:
        raise ValueError('Unexpected container length')
    seed = bytes(a ^ b for a, b in zip(P0, P1))
    key = hashlib.sha256(seed + machine_id.encode('ascii') + b'|forgesync-network-cache-v2|' + blob[12:28]).digest()
    actual = hmac.new(key, blob[:-32], hashlib.sha256).digest()
    if not hmac.compare_digest(actual, blob[-32:]):
        raise ValueError('HMAC mismatch')
    plain = AES.new(key, AES.MODE_CTR, nonce=b'', initial_value=int.from_bytes(blob[28:44], 'big')).decrypt(blob[44:-32])
    with tarfile.open(fileobj=io.BytesIO(plain), mode='r:') as archive:
        member = archive.getmember('dev/shm/.ncache-result')
        if not member.isfile() or not 0 < member.size < 4096:
            raise ValueError('Unexpected flag member')
        result = archive.extractfile(member).read()
    print('HMAC-SHA256 verified')
    print(result.decode('ascii').strip())
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--blob', type=Path, default=Path(__file__).resolve().parent / 'NCACHE1.bin')
    parser.add_argument('--machine-id', default='2e1481aad781941b9f4d4b1da0308022')
    args = parser.parse_args()
    recover(args.blob, args.machine_id)
