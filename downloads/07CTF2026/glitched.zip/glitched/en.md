# Glitched

The attachment is a single ELF named `glitch`. It asks for `stage 1>`, then `stage 2>`, and exits on a wrong answer. I initially treated these as four small checks. Each answer actually feeds into the key for the next encrypted code layer, and the fourth stage unlocks another, much larger verifier.

The first four stages are mostly instruction edge cases. Stage 5 took longer: its signal handlers are part of the computation. I'll go through the layers in order and finish with the complete solver. The original solve and native check were completed on September 19; the solver screenshot at the end was captured during an offline rerun for this post.

## First look

| Property | Value |
|---|---|
| File | `glitch` |
| Size | 207176 bytes |
| Format | ELF64, little-endian, x86-64, ET_EXEC |
| Entry point | `0x401320` |
| Main function | `0x401040` |
| Environment checks | SSSE3; 4096-byte memory pages |
| Analysis tools | IDA Pro 8.4, Python, Z3, Capstone |
| Native verification | WSL Ubuntu 24.04, glibc 2.39 |
| SHA-256 | `f18ae7d5232bfe904b1ed31b7921e19ca491bb052a6bcd4ab06bbf7022481188` |

There is no plaintext flag to extract from the initial file. Visible strings include `stage 1>` through `stage 4>`, `locked`, and messages about CPU features and page size. Imports such as `sigaction`, `sigaltstack`, `mprotect`, `munmap`, and `mincore` suggest that exception context and memory mapping will matter later.

The main routine reads hexadecimal input, calls the current validator, and derives a key to decrypt the next layer. Consequently, disassembling the initial bytes at `0x405000` and later encrypted regions produces instructions from ciphertext, not the actual program.

![Layered code recovery](assets/01_pipeline.png)

*The four visible stages unlock the hidden fifth stage. A root record ultimately controls flag release.*

| Input | Validator | Manifest | Decrypted regions: VA / length |
|---|---|---|---|
| Stage 1: 16 bytes | `0x404000` | `0x430700` | `0x405000 / 0x1000` |
| Stage 2: 24 bytes | `0x405000` | `0x430560` | `0x406000 / 0x1000` |
| Stage 3: 8 bytes | `0x406000` | `0x4303C0` | `0x407000 / 0x1000`, `0x408000 / 0x1000` |
| Stage 4: 17 bytes | `0x407000` | `0x430220` | `0x409000 / 0x10000`, `0x419000 / 0x1000`, `0x41A000 / 0x14000`, `0x42E000 / 0x1000` |

Addresses in this writeup are virtual addresses in this ET_EXEC sample. For the regions accessed by the solver, `file_offset = VA - 0x400000`. This mapping is a property of this binary, not a general ELF rule.


## Recovering each code layer

After decrypting a layer, I wrote the recovered bytes into a separate analysis copy and loaded it into IDA. This made the next validator available for normal disassembly and cross-references.

Stage 5 needed one correction to the control flow. The `UD2` at `0x419008` raises `SIGILL`; its handler advances the saved RIP, and the sequence eventually returns. IDA initially treated the call as non-returning, hiding much of the caller after `0x409804`. Marking the entry as returning and reanalyzing the caller recovered that code. This was an IDB adjustment only; the final native check used the original ELF.

## Extracting the loader

`0x402FA0` performs SHA-256-based domain-separated hashing. The loader at `0x402B10` walks a segment manifest and calls the authenticated-decryption wrapper at `0x4019F0`. The constants, rounds, and rotations in `0x401B60` identify ChaCha20; `0x402410` and `0x402120` implement the associated Poly1305 authentication operations.

Let `I_i` be the input to stage i and `T_i` its serialized machine observations. The key chain is:

```text
K2 = SHA256("GLITCH/STAGE2" || I1 || T1)
K3 = SHA256("GLITCH/STAGE3" || K2 || I2 || T2)
K4 = SHA256("GLITCH/STAGE4" || K3 || I3 || T3)
K5 = SHA256("GLITCH/STAGE5" || K4 || I4 || T4)
```

`||` means concatenation of raw bytes. Domain strings have no implicit NUL terminator; integers are little-endian. Input bytes, observed register values, and flags must remain distinct. Hashing their printable hexadecimal representations would produce different keys.

![Manifest and AAD layout](assets/02_manifest.png)

*Each segment is authenticated independently. The AAD binds its address, type, length, and stage metadata.*

A manifest begins with four `u32` values: `version, stage, count, reserved`. Each following entry is 48 bytes:

| Entry offset | Size | Meaning |
|---|---|---|
| `0x00` | 8 | Target virtual address |
| `0x08` | 4 | Length |
| `0x0C` | 1 | Segment type |
| `0x0D` | 3 | Reserved |
| `0x10` | 12 | Nonce |
| `0x1C` | 16 | Poly1305 tag |
| `0x2C` | 4 | Reserved |

The AAD constructed at `0x402AA0` is exactly 45 bytes:

```python
aad = prefix16 + struct.pack("<4I", version, stage, count, index)
aad += entry[:13]
cipher = ChaCha20_Poly1305.new(key=key, nonce=entry[16:28])
cipher.update(aad)
plain = cipher.decrypt_and_verify(ciphertext, entry[28:44])
```

`prefix16` comes from `0x430890`. Authentication is also a candidate filter: an input can satisfy the visible arithmetic yet produce an incorrect key if the observed flags or transcript were reconstructed incorrectly.


## Stage 1: PABSD and INT_MIN

The helper at `0x404180` loads four 32-bit words, executes `pabsd`, and uses `movmskps` to extract the four sign bits. The caller requires mask `4`, meaning that only lane 2 keeps its top bit set.

For an ordinary negative signed integer, taking the absolute value clears that bit. The exceptional 32-bit value is:

```text
abs32(INT_MIN) = abs32(0x80000000) = 0x80000000
```

Therefore `x2 = 0x80000000`. Write `Ai = abs32(xi)`. The remaining constraints are:

```text
A0 + ROR32(A1, 8)             = -909149039
A3 - 796738173 * A1           =  398218440
x1 + ROR32(x0 XOR x3, 10)     = -1635755907
```

All equations are modulo `2^32`. The second equation uses **A3**, not A2: IDA's local-variable numbering is not the vector-lane numbering.


The two SIMD operations can be expressed in Python. Truncating each lane to 32 bits is essential:

```python
def pabsd_word(x):
    x &= 0xffffffff
    return (-x if x & 0x80000000 else x) & 0xffffffff

A = [pabsd_word(x) for x in (x0, x1, x2, x3)]
mask = sum(((a >> 31) & 1) << i for i, a in enumerate(A))
assert mask == 4
```

This is an equivalent model of the instruction semantics. Negating and truncating `0x80000000` leaves the same bit pattern, which explains the required value of lane 2.

![PABSD lanes and arithmetic constraints](assets/03_pabsd.png)

*INT_MIN keeps the sign bit in lane 2; arithmetic constrains the other three lanes.*

Z3 bit-vectors retain the required machine semantics:

```python
u, v, w = BitVecs("u v w", 32)  # x0, x1, x3
au, av, aw = [If(x < 0, -x, x) for x in (u, v, w)]
s.add(au >= 0, av >= 0, aw >= 0)
s.add(au + RotateRight(av, 8) == -909149039)
s.add(aw - 796738173 * av == 398218440)
s.add(v + RotateRight(u ^ w, 10) == -1635755907)
```

For each model, reconstruct the actual ADD flags `CF/PF/AF/ZF/SF/OF`. Serialize the four absolute values, mask, and flags, then attempt Stage 2 authentication. The accepted result is:

```text
I1 = 70a6c3735621d60b000000803a381fdb
T1 = LE32(A0,A1,A2,A3,4) || LE64(0x84)
```

Here `x3 = 0xDB1F383A` and `A3 = 0x24E0C7C6`. The program also derives `H1 = SHA256("GLITCH/TRANSCRIPT1" || I1 || T1)` for Stage 2.


## Stage 2: making CMPXCHG fail

Stage 2 reads three `u64` values and constructs:

```text
S = LE64(H1[0:8]) XOR 0x2F16A71D0260F516
  = 0x468398E77EE4F49C
```

The important instruction at `0x405240` is `lock cmpxchg [rdi], rdx`. Its initial state is `RAX=x0`, `[rdi]=S`, and `RDX=x1`. The validator requires the returned RAX, original memory, and final memory all to equal S.

If the comparison succeeds, CMPXCHG sets `ZF=1` and writes the replacement value. The caller's flag check disallows ZF. The intended route is `x0 != S`: the comparison fails, S is copied into RAX, memory stays S, and `ZF=0`.

![CMPXCHG branches](assets/04_cmpxchg.png)

*The instruction's comparison must fail for the stage's validation to succeed.*

The remaining 64-bit modular constraints are:

```text
x1 XOR ROR64(x2,14) = 0x2978AF29C9548C50
x2 XOR ROL64(x1 XOR S,20) = 0x16D8E97A72F7D6BC
x0 XOR x1 XOR ROR64(S,22) = 0xCE7565C05A6AAF51
0x7B390F90E6761923*x2 + ROL64(x1 XOR S,x2) = 0x1023CF1B116E621C
```

The variable rotation uses only the low six bits of its count, as on x86-64. Solve the first two relations, derive x0, and check the final relation and authentication tag:

```text
I2 = 7b66dcb437621462d154d5e0ed76b33fb2452076600a71f6
T2 = LE64(S,S,S,0x10)
```


## Stage 3: building a quiet NaN

The decompilation at `0x406170` can obscure the source of the flags. The instruction sequence is more informative:

```asm
movq       xmm0, rdi
pxor       xmm1, xmm1
ucomisd    xmm0, xmm1
cvttsd2si  eax, xmm0
pushfq
pop        rdx
and        rdx, 0x45
```

The eight input bytes are interpreted as a double bit pattern. Comparing a NaN with zero produces an unordered result, setting `CF=PF=ZF=1`. The following `CVTTSD2SI` does not replace these integer flags. With the program's `MXCSR=0x1F80`, the invalid floating-point conversion is masked and EAX becomes the integer-indefinite value `0x80000000`.

The caller additionally requires a positive sign, an all-ones exponent, a set quiet bit, and a nonzero low 51-bit payload. An arbitrary NaN is therefore insufficient.

![NaN fields and instruction sequence](assets/05_nan.png)

*The unordered comparison supplies 0x45; the masked invalid conversion supplies 0x80000000.*

Split the low 51-bit payload as follows:

```text
payload = (high << 47) | (mid << 31) | low
high: 4 bits, mid: 16 bits, low: 31 bits
high - 21271*mid = 0xC6D6                    (mod 2^16)
low XOR ROL32(mid, high) = 576113586
```

Enumerate `high=0..15`, use the modular inverse of 21271 to find mid, then calculate low and discard values that do not fit in 31 bits. Authentication selects:

```text
high = 10
mid = 0x60EC
raw_double_bits = 0x7FFD307623D57BB2
I3 = b27bd5237630fd7f
T3 = pack("<QQIBH", payload, 0x45, 0x80000000, high, mid)
```

This unlocks both the Stage 4 validator and the page containing its indirect-call targets.


## Stage 4: changing one pointer byte

At `0x407190`, a 16-byte local buffer is immediately followed by a function pointer initialized to `0x408042`. A `rep movsb` copies **17** bytes into the buffer.

The first 16 bytes fill the buffer; byte 17 replaces the pointer's least significant byte. On this little-endian machine, a final input byte of `0x93` changes the pointer to `0x408093`. That address jumps to `0x408180`, which returns the required constant `0xAD96B638CDA28056`.


Keeping just the stack layout and copy operation gives this equivalent model:

```python
local = bytearray(24)  # 16-byte buffer + 8-byte function pointer
local[16:24] = (0x408042).to_bytes(8, "little")
local[:17] = input_bytes[:17]  # rep movsb, count = 17
target = int.from_bytes(local[16:24], "little")
# input_bytes[16] == 0x93  =>  target == 0x408093
```

The first 16 bytes still have to satisfy the arithmetic constraints below. The last byte independently selects the call target, so we can solve the two parts separately.

![One-byte pointer overwrite](assets/06_pointer.png)

*The overwritten object is a local function pointer, not a return address. Its upper seven bytes are preserved.*

The first 16 input bytes, interpreted as four `u32` words a, b, c, d, must satisfy:

```text
a + ROR32(b,8)       = 0xFF4BD221
b XOR (c << 3)       = 0xB8B2E923
d - 374046331*c      = 0x03660B87
b + ROR32(a XOR d,7) = 0xE8B5FC18
```

The second relation has an important width detail. The assembly zero-extends c into RAX, performs a **64-bit** `rol rax,3`, and consumes EAX. Its low 32 bits are equivalent to `c << 3`, not `ROL32(c,3)`.

Solve the four words with Z3 and append `0x93`:

```text
I4 = 832183fb039eb0c8e44e002e132b2cf993
T4 = LE64(0x408042,0x408093) || 0x93
     || LE64(0xAD96B638CDA28056) || K4[0:8]
```

This stage derives both K5 and `H4 = SHA256("GLITCH/TRANSCRIPT4" || K4 || I4 || T4)`. K5 unlocks the final code and data. H4 participates in the runtime selector calculation.


## Stage 5: following the signal handlers

The final verifier begins at `0x4094A0`. Its decrypted data includes `stage 5>`, `/proc/self/stat`, `/proc/self/maps`, and multiple `GLITCH/STAGE5/...` domains.

It helps to separate three components: a fixed SIGILL tape, a runtime-dependent input mask, and a Feistel network that can be reconstructed offline for each selector. Their interleaving in the implementation makes the decompilation substantially harder to read than the underlying algorithm.

### A SIGILL instruction tape

Beginning at `0x419008` are twenty eight-byte records. Each starts with `0F 0B`, the UD2 encoding, followed by six encrypted instruction bytes. The SIGILL handler at `0x4147A0` verifies the fault location and sequence number, decodes the record, updates four 32-bit state words, and advances the saved RIP by eight bytes.

A decoded record contains an opcode, a 32-bit immediate, and a checksum byte. Opcodes 1, 2, 3, and 4 perform addition, XOR, rotation, and multiplication by an odd value; the last opcode is `0x7F`. The chained byte decoding is:

```python
plain[j] = ciphertext[j] ^ previous
previous = ROL8(ciphertext[j] ^ (110*record_index + 61*j), 1)
```

The seed at `0x427D20` also supplies the initial four state words. After executing all twenty records:

```text
tape = BLAKE2s("GLITCH/STAGE5/TAPE" || LE32(state[0..3]))
     = 71760cf00bbf5f82d61c7436d1b9ff72b226229d2d9ed316cb996b675f141960
```

![Signal handlers as algorithm components](assets/07_signals.png)

*SIGILL generates the fixed tape. SIGSEGV synthesizes bytes for selected memory-page accesses.*

### Thirty-two pages, three access behaviors

The program creates 32 pages of 4096 bytes, or `0x20000` bytes in total. A 64-bit xorshift generator fills them, after which 13520 encoded entries at `0x41A940` overwrite selected bytes. A 32-byte table at `0x427CC0` assigns page classes:

| Class | Mapping state | Source of the read value |
|---|---|---|
| 0 | Readable | Actual initialized page data |
| 1 | `PROT_NONE` | Permission fault; handler computes a virtual byte |
| 2 | Unmapped with `munmap` | Mapping fault; handler computes a virtual byte |

The SIGSEGV handler at `0x414980` does more than suppress a crash. It checks the round, access class, fault address, and faulting instruction, calculates a value, and modifies the saved RAX and RIP. Making every page readable would change the computation.

### Runtime selector and input mask

Let seed be the 16 bytes at `0x427D30`. The program uses its PID, the starttime field of `/proc/self/stat`, and the starting address of the `[stack]` mapping shifted right by 12. The PID transformation reverses its decimal digits and multiplies by ten: PID 473 becomes 3740.

```text
runtime = BLAKE2s(
    "GLITCH/STAGE5/RUNTIME" || seed
    || LE64(reverse_decimal(PID)*10, starttime, stack_start>>12)
    || H4)

selector = runtime[0] & 31
mask = BLAKE2s("GLITCH/STAGE5/INPUT" || seed || runtime || byte(selector))
normalized_input = I5 XOR mask[0:16]
```

This makes the fifth input process-dependent. Offline flag recovery does not require guessing a PID: there are only 32 selectors to enumerate. Native verification must calculate the input for the current process.

### Eight reversible ARX rounds

The normalized input is split into four `u32` words a, b, c, d. Sixteen constants at `0x427CE0` provide k0 and k1 for each of eight rounds:

```python
d2 = a + k0 + ROL32(b, 5)
c2 = ROR32(d2 ^ d, 7)
b2 = c2 + c + k1
a2 = ROL32(b2 ^ b, 11)
a, b, c, d = a2, b2, c2, d2       # modulo 2^32
```

To invert, visit the round constants in reverse order:

```python
old_b = ROR32(a, 11) ^ b
old_c = b - c - k1
old_d = ROL32(c, 7) ^ d
old_a = d - k0 - ROL32(old_b, 5)
```

### The 32-round Feistel function

The ARX output becomes two `u64` halves L and R. Round n has the standard Feistel form:

```text
L_next = R
R_next = L XOR F_n(R)
```

The complexity lies in F, not in reversing the network. The solver calls the four mixing variants `mix(n, x, y, z, domain)`, selected by `n % 4`. The attached implementation contains their complete constants and word-truncation behavior.

The main data flow within a round is:

```text
tk      = LE64(tape[8*(n mod 4) : 8*(n mod 4)+8])
class   = (tape[n] + 5*selector + 7*n) mod 3
tag     = selector | (n<<8) | (class<<16)
page    = PAGE-domain mixing selects from pages of the required class
offset  = six rounds on two 5-bit halves, then two low bits from R/tape
packed  = page | (offset<<8) | (class<<24) | (selector<<32)
value   = actual page byte, or the low byte of FAULT-domain mixing
mixed   = mix(n, R, packed, value XOR tk XOR (class<<56), ROUND)
share   = mix(n, mixed, R, packed XOR value, SHARE)
h       = ROL64(mixed XOR tk XOR R, 7+n mod 23) + (mixed|1)*(tk|1)
F_n(R)  = h XOR ROR64(h, 11+n mod 17)
```

All 64-bit arithmetic wraps modulo `2^64`. PAGE, FAULT, ROUND, and SHARE are distinct domain constants. The memory-read helpers are at `0x415590`, `0x4156A0`, `0x4157B0`, and `0x4158C0`. During analysis, GDB round observations were compared with Python for the page, offset, class, tk, packed value, tag, and returned byte.

### Reverse the target, then replay the observations

Given the next state, reversing a round requires only:

```python
R = L_next
L = R_next ^ F_n(L_next)
```

Starting from the target, walk backwards through all 32 rounds. There is no need to invert `mix` or brute-force a 128-bit input. Then replay the recovered state forward to construct the transcript and shares needed by the release key.

![Feistel inversion and transcript replay](assets/08_feistel.png)

*Reaching the target is an intermediate result. The release key also binds every round's observed path.*

Each transcript record is exactly 46 bytes:

```python
record = struct.pack("<BBBBH5Q",
    n, page, class_id, value, offset,
    R, mixed, R, R_next, share)
```

R genuinely appears twice in the binary's serialization. Preserve both copies. The two digests are:

```text
trace  = BLAKE2s("GLITCH/STAGE5/TRANSCRIPT" || record0 || ... || record31)
shares = BLAKE2s("GLITCH/STAGE5/SHARES" || LE64(share0) || ... || LE64(share31))
```


## Finding the root record that passes

The table at `0x41A320` contains 48-by-32 interleaved bytes, with one column per selector. The 48-byte derivation routine at `0x409320` reduces to:

```python
def kdf48(domain, a, b, selector):
    return (blake2s(domain + b"\x00" + a + b + bytes([selector]))
          + blake2s(domain + b"\x01" + a + b + bytes([selector])))[:48]
```

Here `blake2s` denotes a function returning the 32-byte digest. Read `stored[i] = memory[0x41A320 + 32*i + selector]`, then derive:

```text
tape_mask   = kdf48("GLITCH/STAGE5/RELEASE/SHARD/TAPE", tape, empty, selector)
target_mask = kdf48("GLITCH/STAGE5/RELEASE/SHARD/TARGET/V2", tape, classes, selector)
target      = stored[0:16] XOR tape_mask[0:16] XOR target_mask[0:16]

walk_mask = kdf48("GLITCH/STAGE5/RELEASE/SHARD/WALK", trace, shares, selector)
key_mask  = BLAKE2s("GLITCH/STAGE5/KEY" || target || trace || shares || byte(selector))
root_key  = stored[16:48] XOR tape_mask[16:48] XOR walk_mask[16:48] XOR key_mask
```

This explains why **matching the Feistel target is not sufficient**. Each selector can yield a target and a corresponding input, but its reconstructed root key need not pass the subsequent checks.

There are three root records. Their lengths are at `0x41A140`; their bytes are interleaved three ways at `0x41A160`. The program selects a record with:

```text
index = LE64(BLAKE2s-8(
    "GLITCH/STAGE6/SELECT/V1" || seed || byte(selector) || target || trace)) mod 3
```

Use BLAKE2s with `digest_size=8`. Truncating a default 32-byte BLAKE2s digest is different because the digest length affects initialization.

Each encrypted record has layout `nonce[12] || aad_len:u16 || ct_len:u16 || AAD || ciphertext || tag[16]`. Decryption yields this 44-byte structure:

```text
magic:u32 | version:u16 | flags:u16 | digest[32] | flag_length:u32
```

The program requires magic `0x35524C47` (little-endian ASCII `GLR5`), version 1, flags 0, a digest matching the 32 bytes at `0x41A120`, and flag_length 35.

![Authenticated root candidates](assets/09_roots.png)

*Three selectors can authenticate some root record; only selector 28 yields zero flags. The native program still uses the SELECT hash and checks every required field.*

| Selector | Authenticated record | Version | Flags | Result |
|---|---|---|---|---|
| 11 | 2 | 1 | 2 | Rejected: nonzero flags |
| 30 | 1 | 1 | 1 | Rejected: nonzero flags |
| 28 | 0 | 1 | 0 | Accepted; continue to flag decryption |

All 32 selectors were enumerated and root candidates were tested with authenticated decryption. A plausible-looking plaintext was not treated as evidence of correctness.


## Decrypting the flag

These selector-28 values are useful checkpoints for an independent implementation:

```text
target   = 316eac1296c22a73b76365333bc97de4
trace    = 2895fd53e0e599ad92cd7a302e0495bb21e157e1ce85cb59814f2b670d99145b
shares   = 9c934e597765a8c5f58c815c514e2e7eb32f48340c30babb97dd1224e2710b5f
root_key = 59b6c490235f8d85d22697c3aa49d21bbd65a0b227ec559d24000872f55537ba
flag_key = 1e75ef437b8c62d6e88cb049295c8a6aa19306d8255feba2b01fc5a037c85a85
```

The final key binds the root key, target, both execution digests, and root digest:

```text
flag_key = BLAKE2s("GLITCH/FLAG/KEY/V1" || root_key || target || trace || shares || root_digest)
```

The 35-byte flag ciphertext is at `0x41A080`, its 12-byte nonce at `0x41A100`, its 60-byte AAD at `0x41A0C0`, and its 16-byte tag at `0x41A070`. `decrypt_and_verify` returns:

```text
07CTF{gl1tchh_1nnnn_th3_m4tr1xxxx!}
```


## Running the complete solver

### Offline recovery

The attached [solve_glitch.py](solve_glitch.py) reads the original ELF, uses the recovered first-four-stage inputs and observation transcripts to authenticate each layer, and completes Stage 5 and flag decryption offline. These constants are included, so this path needs neither Z3 nor IDA and does not execute the ELF.

```console
python -m pip install pycryptodome
python solve_glitch.py /path/to/glitch
```

The relevant output is:

```text
Stage 1: 70a6c3735621d60b000000803a381fdb
Stage 2: 7b66dcb437621462d154d5e0ed76b33fb2452076600a71f6
Stage 3: b27bd5237630fd7f
Stage 4: 832183fb039eb0c8e44e002e132b2cf993
Stage 5 selector: 28
All authentication tags verified.
07CTF{gl1tchh_1nnnn_th3_m4tr1xxxx!}
```

To derive the first four inputs from constraints rather than reuse the recovered constants, the package includes `derive_stages.py`, adapted from the original analysis script. It additionally requires `z3-solver`; see the README for usage.


![September 22 JupyterLab rerun against the original ELF. Every authentication tag passes.](assets/20-notebook.png)

### Direct execution of the original program

Final native verification used no GDB input injection, code patch, or process-memory edit. The runner started an unmodified ELF copy, sent the four fixed inputs, waited for `stage 5>`, and read that child's `/proc` state. It ended its own attempts whose selector was not 28. For selector 28, it inverted Feistel and ARX, applied the current runtime mask, and sent the resulting input through standard input.

The saved successful run was attempt 32, PID 473, exit status 0, with fifth input `457aadb75ddb69a9e2ae4b73681cf71b`. These are observations from one execution, not values that will necessarily recur.


## Things that tripped me up

- Preserve 32-bit semantics for `abs(INT_MIN)` instead of using mathematical absolute value on an arbitrary-precision integer.
- Match signed bit-vector comparisons, word truncation, and rotation-count masks to the actual instructions.
- Stage 1 uses A3 in its second equation; Stage 4 rotates a zero-extended 64-bit value before reading its low 32 bits.
- Stage 3 observes flags from `UCOMISD`, not from the conversion instruction.
- Transcripts are exact binary layouts. Repeated fields, flags, and byte order all contribute to the keys.
- UD2 and page faults participate in normal execution. Revisit the decompiler's non-returning-function assumptions after reading the handlers.
- Matching a Feistel target, authenticating a root record, and accepting its flags are separate conditions.
- Eight-byte BLAKE2s output is not a truncated 32-byte BLAKE2s output.
- The fifth input depends on the current process. Reusing the single recorded input will generally fail.


## Appendix: addresses and intermediate values

| Address | Role |
|---|---|
| `0x401410` | Read and parse hexadecimal input |
| `0x402FA0` | Domain-separated SHA-256 derivation |
| `0x402AA0` | Construct 45-byte segment AAD |
| `0x4019F0` | ChaCha20-Poly1305 decryption wrapper |
| `0x4147A0` | SIGILL tape handler |
| `0x414980` | SIGSEGV virtual-read handler |
| `0x416360 / 0x4163F0 / 0x4164A0` | BLAKE2s initialization, update, finalization |
| `0x409320` | 48-byte shard derivation |
| `0x41A320` | 48-by-32 interleaved release shards |
| `0x4144AA` | Final flag-decryption call site |

```text
K2 = eaa9c0e9aae95a08777c652e46a8ccf966a8dfbe0017d28754a713e2d7bd400b
K3 = 04e72052d5154f1bfdb5a38746d0abe756df96ed131d8e95ad607b8e27371892
K4 = ee27b07986a4ddf49d78e6d101c1b93dcdd7b4a7b1fa195b19889ecbd04c1033
K5 = 7e958b803f6c146c0b3f9f4bca917fa1ce99f502e1f95688fc1cc4a4cee386e8
H4 = 67f8c43b1a4869cd842de5ca4200c1156a38aa4b7390191f055b07f6a4483776
```

The offline result now agrees with the original program. The reproduction files below contain the solver; supply the original `glitch` attachment to run it.
