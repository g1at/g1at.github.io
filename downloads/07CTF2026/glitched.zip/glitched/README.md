# Glitched — reproduction

Use the original `glitch` challenge attachment (not redistributed here).
SHA-256: `f18ae7d5232bfe904b1ed31b7921e19ca491bb052a6bcd4ab06bbf7022481188`.

## Offline solve

```sh
python -m pip install pycryptodome
python solve_glitch.py /path/to/glitch
```

This reads the ELF as bytes. It does not run the sample. All encrypted layers and
the final flag are authenticated.

## Derive stages 1–4 from constraints

```sh
python -m pip install pycryptodome z3-solver
python derive_stages.py /path/to/glitch --out derived
```

The `derived` directory receives stage records and decrypted analysis copies.
`evidence/native_verified.json` records the original native run, rather than a new
execution. Stage 5 input depends on process state and cannot be reused generally.
