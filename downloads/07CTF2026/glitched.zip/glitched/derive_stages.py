import struct, hashlib, itertools, json, argparse
from pathlib import Path
from Crypto.Cipher import ChaCha20_Poly1305
from z3 import BitVecs, If, RotateRight, RotateLeft, Solver, sat, Or

parser = argparse.ArgumentParser(description='Derive the first four GLITCH stages without executing the ELF')
parser.add_argument('sample', type=Path)
parser.add_argument('--out', type=Path, default=Path('derived'))
args = parser.parse_args()
ROOT = args.out.resolve()
ROOT.mkdir(parents=True, exist_ok=True)
B = bytearray(args.sample.read_bytes())
MASK=0xffffffff
def rol(x,n): return ((x<<n)|(x>>(32-n)))&MASK
def ror(x,n): return rol(x,32-n)
def p32(x):return struct.pack('<I',x&MASK)
def addflags(a,b):
 r=(a+b)&MASK
 return int(a+b>MASK)|((int((r&255).bit_count()%2==0))<<2)|(((a^b^r)&16))|(int(r==0)<<6)|(r&0x80000000)>>24|((~(a^b)&(a^r)&0x80000000)>>20)
def mem(addr,size):return bytes(B[addr-0x400000:addr-0x400000+size])
def unlock(manifest,key,output=True):
 version,stage,count,res=struct.unpack('<4I',mem(manifest,16))
 chunks=[]
 for idx in range(count):
  ent=mem(manifest+16+48*idx,48)
  addr,length,kind=struct.unpack('<QIB',ent[:13])
  nonce,tag=ent[16:28],ent[28:44]
  aad=mem(0x430890,16)+struct.pack('<4I',version,stage,count,idx)+ent[:13]
  cipher=ChaCha20_Poly1305.new(key=key,nonce=nonce);cipher.update(aad)
  plain=cipher.decrypt_and_verify(mem(addr,length),tag)
  chunks.append((addr,plain))
 if output:
  for addr,plain in chunks:B[addr-0x400000:addr-0x400000+len(plain)]=plain
 return chunks

def stage1():
 saved=ROOT/'stage1.json'
 if saved.exists():
  rec=json.loads(saved.read_text());x,t,k=[bytes.fromhex(rec[n]) for n in ['input','transcript','key']]
  unlock(0x430700,k);return x,t,k
 u,v,w=BitVecs('u v w',32)
 au,av,aw=[If(x<0,-x,x) for x in [u,v,w]]
 solver=Solver()
 solver.add(au+RotateRight(av,8)==-909149039, aw-796738173*av==398218440, v+RotateRight(u^w,10)==-1635755907)
 solver.add(au>=0,av>=0,aw>=0)
 while solver.check()==sat:
  model=solver.model();x0,x1,x3=[model.eval(x).as_long() for x in [u,v,w]]
  solver.add(Or(u!=x0,v!=x1,w!=x3))
  rotated=ror(x0^x3,10)
  x=struct.pack('<4I',x0,x1,0x80000000,x3)
  ab=[abs(v)&MASK for v in struct.unpack('<4i',x)]
  transcript=struct.pack('<5IQ',*ab,4,addflags(rotated,x1))
  key=hashlib.sha256(b'GLITCH/STAGE2'+x+transcript).digest()
  try:unlock(0x430700,key)
  except ValueError:
   print('rejected candidate',x.hex(),flush=True)
   continue
  print('stage1',x.hex(), 'key',key.hex(),flush=True)
  (ROOT/'stage1.json').write_text(json.dumps({'input':x.hex(),'transcript':transcript.hex(),'key':key.hex()}))
  (ROOT/'glitch_stage2').write_bytes(B)
  return x,transcript,key
 raise ValueError('No stage1 candidate validated')
def rol64(x,n):
 n&=63
 return ((x<<n)|(x>>((64-n)&63)))&((1<<64)-1)
def ror64(x,n):return rol64(x,64-n)
def subflags(a,b):
 r=(a-b)&((1<<64)-1)
 return int(a<b)|(int((r&255).bit_count()%2==0)<<2)|((a^b^r)&16)|(int(r==0)<<6)|((r>>63)<<7)|(((a^b)&(a^r)&(1<<63))>>52)
def stage2(x,t,k):
 h=hashlib.sha256(b'GLITCH/TRANSCRIPT1'+x+t).digest()
 state=struct.unpack('<Q',h[:8])[0]^0x2F16A71D0260F516
 u,v=BitVecs('s2_u s2_v',64)
 solver=Solver()
 solver.add(u^RotateRight(v,14)==0x2978AF29C9548C50,v^RotateLeft(u^state,20)==0x16D8E97A72F7D6BC)
 while solver.check()==sat:
  m=solver.model();x1,x2=[m.eval(j).as_long() for j in [u,v]];solver.add(Or(u!=x1,v!=x2))
  x0=x1^ror64(state,22)^0xCE7565C05A6AAF51
  if ((0x7B390F90E6761923*x2+rol64(x1^state,x2))&((1<<64)-1))!=0x1023CF1B116E621C:continue
  x=struct.pack('<3Q',x0,x1,x2)
  t=struct.pack('<4Q',state,state,state,subflags(x0,state))
  key=hashlib.sha256(b'GLITCH/STAGE3'+k+x+t).digest()
  unlock(0x430560,key)
  print('stage2',x.hex(),'key',key.hex(),flush=True)
  (ROOT/'stage2.json').write_text(json.dumps({'input':x.hex(),'transcript':t.hex(),'key':key.hex()}))
  (ROOT/'glitch_stage3').write_bytes(B)
  return x,t,key
 raise ValueError('stage2 failed')
def stage3(x,t,k):
 for high in range(16):
  mid=((high-0xC6D6)*pow(21271,-1,1<<16))&0xffff
  low=576113586^rol(mid,high)
  if low>=1<<31:continue
  payload=(high<<47)|(mid<<31)|low
  x=struct.pack('<Q',0x7ff8000000000000|payload)
  t=struct.pack('<QQIBH',payload,0x45,0x80000000,high,mid)
  key=hashlib.sha256(b'GLITCH/STAGE4'+k+x+t).digest()
  try:unlock(0x4303c0,key)
  except ValueError:continue
  print('stage3',x.hex(),'key',key.hex(),flush=True)
  (ROOT/'stage3.json').write_text(json.dumps({'input':x.hex(),'transcript':t.hex(),'key':key.hex()}))
  (ROOT/'glitch_stage4').write_bytes(B)
  return x,t,key
 raise ValueError('stage3 failed')
def stage4(x,t,k):
 a,b,c,d=BitVecs('s4_a s4_b s4_c s4_d',32)
 solver=Solver()
 solver.add(a+RotateRight(b,8)==-11808223,b^(c<<3)==-1196234461,d-374046331*c==57019271,b+RotateRight(a^d,7)==-390726632)
 while solver.check()==sat:
  m=solver.model();vals=[m.eval(j).as_long() for j in [a,b,c,d]];solver.add(Or(*[j!=v for j,v in zip([a,b,c,d],vals)]))
  x=struct.pack('<4IB',*vals,0x93)
  t=struct.pack('<QQBQ',0x408042,0x408093,0x93,0xAD96B638CDA28056)+k[:8]
  key=hashlib.sha256(b'GLITCH/STAGE5'+k+x+t).digest()
  try:unlock(0x430220,key)
  except ValueError:
   print('stage4 rejected',x.hex(),flush=True)
   continue
  print('stage4',x.hex(),'key',key.hex(),flush=True)
  h=hashlib.sha256(b'GLITCH/TRANSCRIPT4'+k+x+t).digest()
  (ROOT/'stage4.json').write_text(json.dumps({'input':x.hex(),'transcript':t.hex(),'key':key.hex(),'transcript4':h.hex()}))
  (ROOT/'glitch_final').write_bytes(B)
  return x,t,key,h
 raise ValueError('stage4 failed')
if __name__=='__main__':stage4(*stage3(*stage2(*stage1())))
